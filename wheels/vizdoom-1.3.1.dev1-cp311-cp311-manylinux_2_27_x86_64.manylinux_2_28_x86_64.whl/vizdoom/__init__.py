import sys as _sys

# Version check and import
_COMPILED_PYTHON_VERSION = "3.11"

_this_python_version = f"{_sys.version_info.major}.{_sys.version_info.minor}"

if _COMPILED_PYTHON_VERSION != _this_python_version:
    raise SystemError(
        f"This interpreter version: '{_this_python_version}' doesn't match with version of the interpreter ViZDoom was compiled with: '{_COMPILED_PYTHON_VERSION}'"
    )

from .vizdoom import __version__ as __version__
from .vizdoom import *


# Path helpers
import os as _os

root_path = __path__[0]
install_path = root_path  # alias
exe_path_windows = _os.path.join(__path__[0], "vizdoom.exe")
exe_path_unix = _os.path.join(__path__[0], "vizdoom")
exe_path = exe_path_windows if _os.path.exists(exe_path_windows) else exe_path_unix
scenarios_path = _os.path.join(__path__[0], "scenarios")
wads = [wad for wad in sorted(_os.listdir(scenarios_path)) if wad.endswith(".wad")]
configs = [cfg for cfg in sorted(_os.listdir(scenarios_path)) if cfg.endswith(".cfg")]


# Farama notifications
try:
    from farama_notifications import notifications  # type: ignore

    if "vizdoom" in notifications and __version__ in notifications["vizdoom"]:
        print(notifications["vizdoom"][__version__], file=_sys.stderr)
except Exception:  # nosec
    pass
